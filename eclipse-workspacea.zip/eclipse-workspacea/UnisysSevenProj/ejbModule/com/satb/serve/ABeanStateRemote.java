package com.satb.serve;

import javax.ejb.Remote;

@Remote
public interface ABeanStateRemote {
	public String wrFile(String conts);

}
