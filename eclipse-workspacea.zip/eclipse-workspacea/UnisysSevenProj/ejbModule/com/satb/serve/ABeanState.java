package com.satb.serve;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;


@Stateful
public class ABeanState implements ABeanStateRemote,Ivals {

    public ABeanState() {
    }

	@Override
	public String wrFile(String conts) {
		File f=new File(fname);
		String status="not done";
		try {
			FileOutputStream fos=new FileOutputStream(f);
			fos.write(conts.getBytes());
			fos.flush();
			fos.close();
			status="done";
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return status;
	}
}
