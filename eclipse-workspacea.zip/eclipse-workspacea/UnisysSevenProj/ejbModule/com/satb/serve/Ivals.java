package com.satb.serve;

public interface Ivals {
	public static final String fname="C:\\File\\unisysdata.txt";

}
