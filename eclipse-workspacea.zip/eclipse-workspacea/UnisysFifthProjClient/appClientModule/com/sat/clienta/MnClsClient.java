package com.sat.clienta;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sat.serva.FileBeanA;
import com.sat.serva.FileBeanARemote;

public class MnClsClient {

	public static void main(String[] args) throws NamingException {
		FileBeanARemote fa=EJBContextFactory.retBean("ejb:");
		String u=fa.retContents();
		System.err.println(u);
		String b=fa.retBook();
		System.out.println(b);
	}
	
	private static class EJBContextFactory {
		private static FileBeanARemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}

		private static FileBeanARemote retLookUp(String namespace) throws NamingException {
			Context ctx = creaInitContext();
			String appName = "";
			String moduleName = "UnisysFifthProj";
			String distinctName = "";
			String beanName = FileBeanA.class.getSimpleName();
			String viewClassName = FileBeanARemote.class.getName();
			return (FileBeanARemote) ctx.lookup(
					namespace + appName + "/" + moduleName + "/" + distinctName + "/" + beanName + "!" + viewClassName);
		}

		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}
	

}