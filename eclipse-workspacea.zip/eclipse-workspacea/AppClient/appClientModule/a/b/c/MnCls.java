package a.b.c;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import co.sa.cl.ABean;
import co.sa.cl.ABeanRemote;

public class MnCls {

	public static void main(String[] args) throws NamingException {
			ABeanRemote ab=EJBFactory.lookupTextProcessorBean("ejb:");
			System.out.println(ab.tester());
	}

	private static class EJBFactory {

        private static ABeanRemote createTextProcessorBeanFromJNDI
          (String namespace) throws NamingException {
            return lookupTextProcessorBean(namespace);
        }

        private static ABeanRemote lookupTextProcessorBean
          (String namespace) throws NamingException {
            Context ctx = createInitialContext();
            String appName = "";
            String moduleName = "FirstProjEjb";
            String distinctName = "";
            String beanName = ABean.class.getSimpleName();
            String viewClassName = ABeanRemote.class.getName();
            return (ABeanRemote) ctx.lookup(namespace 
              + appName + "/" + moduleName 
              + "/" + distinctName + "/" + beanName + "!" + viewClassName+"?stateful");
        }

        private static Context createInitialContext() throws NamingException {
            Properties jndiProperties = new Properties();
            jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, 
              "org.jboss.naming.remote.client.InitialContextFactory");
            jndiProperties.put(Context.URL_PKG_PREFIXES, 
              "org.jboss.ejb.client.naming");
            jndiProperties.put(Context.PROVIDER_URL, 
               "http-remoting://localhost:8080");
            jndiProperties.put("jboss.naming.client.ejb.context", true);
            return new InitialContext(jndiProperties);
        }
	
	
	
	
}
}
