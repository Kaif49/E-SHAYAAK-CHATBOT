package com.sat.ejbse;

import javax.ejb.Remote;

@Remote
public interface CBeanRemote {
	public String retRev(String b);
	public double retRoot(int i);
}