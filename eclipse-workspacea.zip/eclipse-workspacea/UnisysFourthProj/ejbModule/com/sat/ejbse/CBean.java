package com.sat.ejbse;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class CBean
 */
@Stateless
public class CBean implements CBeanRemote {
    public CBean() {
    }

	@Override
	public String retRev(String b) {
		StringBuffer buf=new StringBuffer(b);
		String j=buf.reverse().toString();
		return j;
	}

	@Override
	public double retRoot(int i) {
		return Math.sqrt(i);
	}
}