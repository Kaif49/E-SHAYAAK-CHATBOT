package com.sat.servef;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class MyBeanD
 */
@Stateless
@LocalBean
public class MyBeanD implements MyBeanDRemote {

    
    public MyBeanD() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String mMeth() {
		return "Iam A String From EJB by KAIF;";
	}

}
