package com.sat.servef;

import javax.ejb.Remote;

@Remote
public interface MyBeanDRemote {
	public String mMeth();

}
