package pp.qq.rr;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sat.ejbse.CBean;
import com.sat.ejbse.CBeanRemote;

public class MnCls {

	public static void main(String[] args) throws NamingException {
		CBeanRemote cr=EJBContextFactory.retBean("ejb:");
		System.out.println(cr.retRev("Satish"));
System.out.println(cr.retRoot(21));
		
	}
	private static class EJBContextFactory {
		private static CBeanRemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}

		private static CBeanRemote retLookUp(String namespace) throws NamingException {
			Context ctx = creaInitContext();
			String appName = "";
			String moduleName = "UnisysFourthProj";
			String distinctName = "";
			String beanName = CBean.class.getSimpleName();
			String viewClassName = CBeanRemote.class.getName();
			return (CBeanRemote) ctx.lookup(
					namespace + appName + "/" + moduleName + "/" + distinctName + "/" + beanName + "!" + viewClassName);
		}

		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}
}