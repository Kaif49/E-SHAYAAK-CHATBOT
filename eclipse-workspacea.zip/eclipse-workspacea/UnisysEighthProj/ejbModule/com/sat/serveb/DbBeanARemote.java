package com.sat.serveb;

import javax.ejb.Remote;

@Remote
public interface DbBeanARemote {
	public String retConts();
	public String insPerson(int a,String b,String c);
	public String upPerson(int a,String b,String c);
	public String delPerson(int a);
	


}
