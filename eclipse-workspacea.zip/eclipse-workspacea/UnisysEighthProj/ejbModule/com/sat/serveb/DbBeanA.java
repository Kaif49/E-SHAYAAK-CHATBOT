package com.sat.serveb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Session Bean implementation class DbBeanA
 */
@Stateful
@LocalBean
public class DbBeanA implements DbBeanARemote {
    public DbBeanA() {
    }

	@Override
	public String retConts() {
		String res="";
		try {
			DataSource ds=(DataSource)(new InitialContext().lookup("java:jboss/MySqlDS"));
			Connection conn=ds.getConnection();
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from persons");
			
			while(rs.next()) {
				res+=rs.getInt(1)+"-"+rs.getString(2)+"-"+rs.getString(3)+";";
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	@Override
	public String insPerson(int a, String b, String c) {
		String status="Not Done";
		 try {
			DataSource ds=(DataSource)(new InitialContext().lookup("java:jboss/MySqlDS"));
			Connection conn=ds.getConnection();
			PreparedStatement ps=conn.prepareStatement("insert into persons values(?,?,?)");
			ps.setInt(1, a);
			ps.setString(2, b);
			ps.setString(3, c);
			ps.execute();
			status="Done";
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public String upPerson(int a, String b, String c) {
		String status="Not Done";
		 try {
			DataSource ds=(DataSource)(new InitialContext().lookup("java:jboss/MySqlDS"));
			Connection conn=ds.getConnection();
			PreparedStatement ps=conn.prepareStatement("update persons set name=?,dept=? where id=?");
			ps.setString(1, b);
			ps.setString(2, c);	
			ps.setInt(3, a);
			ps.executeUpdate();
			status="Done";
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public String delPerson(int a) {
		String status="Not Done";
		 try {
			DataSource ds=(DataSource)(new InitialContext().lookup("java:jboss/MySqlDS"));
			Connection conn=ds.getConnection();
			PreparedStatement ps=conn.prepareStatement("delete from persons where id=?");
			ps.setInt(1, a);
			ps.executeUpdate();
			status="Done";
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	} 
    
}