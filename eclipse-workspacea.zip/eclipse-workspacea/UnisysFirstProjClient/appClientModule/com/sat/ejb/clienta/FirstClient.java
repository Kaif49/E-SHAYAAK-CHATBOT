package com.sat.ejb.clienta;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ejb.ser.sat.FirstBean;
import com.ejb.ser.sat.FirstBeanRemote;

public class FirstClient {

	public static void main(String[] args) throws NamingException {
		
		FirstBeanRemote fb = EJBContextFactory.retBean("ejb:");
		
		System.out.println("*****"+fb.myMetha());

	}
	
	
	private static class EJBContextFactory{
		private static FirstBeanRemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}
		private static FirstBeanRemote retLookUp(String namespace) throws NamingException {
			Context ctx=creaInitContext();
			String appName="";
			String moduleName="UnisysFirstProj";
			String distinctName="";
			String beanName=FirstBean.class.getSimpleName();
			String ViewClassName = FirstBeanRemote.class.getName();
			
			return (FirstBeanRemote)ctx.lookup(namespace+appName+"/"+moduleName+"/"+distinctName+"/"+beanName+"!"+ViewClassName);
		}
		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}
}
