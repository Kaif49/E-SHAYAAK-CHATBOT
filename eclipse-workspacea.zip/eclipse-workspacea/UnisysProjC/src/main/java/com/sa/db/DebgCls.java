package com.sa.db;

public class DebgCls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbUtils dbutils = new DbUtils();
		System.out.println(dbutils.retRegs().size());
	}

}
