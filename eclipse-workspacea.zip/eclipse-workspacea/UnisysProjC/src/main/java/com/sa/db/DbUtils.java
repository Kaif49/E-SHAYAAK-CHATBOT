package com.sa.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sat.mods.Register;

public class DbUtils {

	Connection conn = null;

	public DbUtils() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/unifirst", "root", "unisys@1321");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/***
	 * Select query on table
	 * @return List of register objects from db
	 */
	public List<Register> retRegs() {
		List<Register> lreg=new ArrayList<Register>();
		try {
			PreparedStatement ps=conn.prepareStatement("select * from register");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Register r=new Register();
				r.setId(rs.getInt(1));
				r.setName(rs.getString(2));
				r.setEmail(rs.getString(3));
				r.setMobile(rs.getString(4));
				lreg.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lreg;
	}

	/***
	 * Inserts a new record into the table
	 * @param r
	 * @return
	 */
	public String insReg(Register r) {
		String status="Notdone";
		int a=r.getId();
		String b=r.getName();
		String c=r.getEmail();
		String d=r.getMobile();
		String query="insert into register values (?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, a);
			ps.setString(2, b);
			ps.setString(3, c);
			ps.setString(4, d);
			ps.execute();
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	/***
	 * Updates the given record into the table
	 * @param r
	 * @return
	 */
	public String upsReg(Register r) {
		String status="Notdone";
		int a=r.getId();
		String b=r.getName();
		String c=r.getEmail();
		String d=r.getMobile();
		String query="update register set name=?,email=?,mobile=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, b);
			ps.setString(2, c);
			ps.setString(3, d);
			ps.setInt(4, a);
			ps.executeUpdate();
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	/***
	 * Deletes the record from the register table
	 * @param id
	 * @return
	 */
	public String delReg(int id) {
		String status="Notdone";
		String query="delete from register where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, id);
			ps.executeUpdate();
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
}
