package co.sa.cl;

public class Books {
 private int bid;
 private String bname;
 private String bauth;
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getBauth() {
	return bauth;
}
public void setBauth(String bauth) {
	this.bauth = bauth;
}
}
