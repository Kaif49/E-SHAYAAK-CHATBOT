package com.sat.serva;

import javax.ejb.Remote;

@Remote
public interface FirstBeanARemote {
	public String retContents();
	public Books retBook();
}