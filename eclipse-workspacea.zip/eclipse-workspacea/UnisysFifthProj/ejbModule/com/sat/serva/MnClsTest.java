package com.sat.serva;

public class MnClsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirstBeanA bean=new FirstBeanA();
		System.out.println(bean.retContents());

	}

}
