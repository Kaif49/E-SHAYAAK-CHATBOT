package com.sat.serva;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class FileBeanA
 */
@Stateless
@LocalBean
public class FirstBeanA implements FirstBeanARemote {
	private final String fname="C:\\DelhiOfficeFiles\\ServletNotes.txt";
    public FirstBeanA() {
    }

	@Override
	public String retContents() {
		File f=new File(fname);
		String fCont="";
		try {
			FileInputStream fis=new FileInputStream(f);
			int i=0;
			while((i=fis.read())!=-1) {
				fCont+=(char)i;
			}
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fCont;
	}

	@Override
	public Books retBook() {
		Books b=new Books();
		b.setBid(1223);
		b.setBname("Meghasandesam");
		b.setBauth("Mahakavi Kalidasa");
		return b;
	}

}