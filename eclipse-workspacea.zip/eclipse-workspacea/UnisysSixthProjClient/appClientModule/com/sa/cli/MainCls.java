package com.sa.cli;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sata.serve.MYSBean;
import com.sata.serve.MYSBeanRemote;

public class MainCls {
	public static void main(String[] args) throws NamingException {
		MYSBeanRemote msb=EJBContext.retBean("ejb:");
		String j=msb.retSecLetterCaps("this is rather a long string to be a part of parameter");
		System.out.println(j);
	}

	private static class EJBContext {
		private static MYSBeanRemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}

		private static MYSBeanRemote retLookUp(String namespace) throws NamingException {
			Context ctx = creaInitContext();
			String appName = "";
			String moduleName = "UnisysSixthProj";
			String distinctName = "";
			String beanName = MYSBean.class.getSimpleName();
			String viewClassName = MYSBeanRemote.class.getName();
			return (MYSBeanRemote) ctx.lookup(namespace + appName + "/" + moduleName + "/" + distinctName + "/"
					+ beanName + "!" + viewClassName + "?stateful");
		}

		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}
}