package co.sa.clia;

import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.satb.serve.ABeanState;
import com.satb.serve.ABeanStateRemote;

public class MnClsA {

	public static void main(String[] args) throws NamingException {
		Person[] pArr=new Person[5];
		Scanner scan=new Scanner(System.in);
		int i=0;
		while(i<5) {
			System.out.println("Enter the name of the person");
			String name=scan.nextLine();
			System.out.println("Enter the email of the person");
			String email=scan.nextLine();
			System.out.println("Enter the mobile of the person");
			String mobile=scan.nextLine();
			Person pObj=new Person(name, email, mobile);
			pArr[i]=pObj;
			i++;
		}
		String resp=Arrays.deepToString(pArr);
		ABeanStateRemote abs=EJBContext.retBean("ejb:");
		abs.wrFile(resp);
	}
	
	private static class EJBContext{
		private static ABeanStateRemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}

		private static ABeanStateRemote retLookUp(String namespace) throws NamingException {
			Context ctx = creaInitContext();
			String appName = "";
			String moduleName = "UnisysSevenProj";
			String distinctName = "";
			String beanName = ABeanState.class.getSimpleName();
			String viewClassName = ABeanStateRemote.class.getName();
			return (ABeanStateRemote) ctx.lookup(namespace + appName + "/" + moduleName + "/" + distinctName + "/"
					+ beanName + "!" + viewClassName + "?stateful");
		}

		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}
}