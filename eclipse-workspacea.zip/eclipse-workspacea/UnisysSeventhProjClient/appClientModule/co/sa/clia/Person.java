package co.sa.clia;

public class Person {
	private String pname;
	private String pemail;
	private String pmobile;
	public Person() {
	}
	public Person(String a,String b,String c) {
		this.pname=a;
		this.pemail=b;
		this.pmobile=c;
	}
	@Override
	public String toString() {
		String fin=String.format("Name:%s Email: %s Mobile:%s", this.pname,this.pemail,this.pmobile);
		return fin;
	}
}