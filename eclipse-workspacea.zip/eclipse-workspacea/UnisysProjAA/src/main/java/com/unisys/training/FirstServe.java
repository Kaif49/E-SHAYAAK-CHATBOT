package com.unisys.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.cls.mods.Cars;

/**
 * Servlet implementation class FirstServe
 */
@WebServlet("/FirstServe")
public class FirstServe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.addHeader("content-type", "text/html");
//		PrintWriter out=response.getWriter();
//		String j="Iam coming from previous servlet";
//		HttpSession sess=request.getSession();
//		sess.setAttribute("val", j);
//		Cookie cook = new Cookie("cooka", "This is val of cookie");
//		response.addCookie(cook);
//		out.println("<h1>First Servlet</h1>");
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		String j="Iam coming from previous servlet";
		HttpSession sess=request.getSession();
		Cars c=new Cars();
		c.setCid(212);
		c.setCname("Brando");
		c.setCbrand("Citroen");
		sess.setAttribute("val", j);
		sess.setAttribute("car", c);
		//Client Side
		Cookie cook=new Cookie("cooka", "This is val of cookie");
		response.addCookie(cook);
		//Client side
		response.sendRedirect("./SecServe?name=mukesh&email=mukesh@yahoo.com&mobile=93838383838");
		out.println("<h1>First Servlet</h1>");
////
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
