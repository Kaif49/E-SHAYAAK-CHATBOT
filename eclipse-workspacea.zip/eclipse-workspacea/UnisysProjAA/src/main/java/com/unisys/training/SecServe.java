package com.unisys.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.cls.mods.Cars;

/**
 * Servlet implementation class SecServe
 */
@WebServlet("/SecServe")
public class SecServe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecServe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.addHeader("content-type", "text/html");
//		PrintWriter out=response.getWriter();
//		HttpSession sess=request.getSession();
//		if(sess.getAttribute("val")!=null) {
//			out.println("<h1>The value from other serv is "+sess.getAttribute("val").toString()+"</h1>");
//		}
//		if(sess.getAttribute("car")!=null) {
//			Cars cc=(Cars)sess.getAttribute("car");
//			out.println(cc.getCid()+" "+cc.getCname()+" "+cc.getCbrand());
//		}
//		Cookie[] cArr=request.getCookies();
//		for(Cookie co:cArr) {
//			if(co.getName().equals("cooka"))
//			out.println(co.getName()+" "+co.getValue());
//		}
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession();
		if(sess.getAttribute("val")!=null) {
			out.println("<h1>The value from other serv is "+sess.getAttribute("val").toString()+"</h1>");
		}
		if(sess.getAttribute("car")!=null) {
			Cars cc=(Cars)sess.getAttribute("car");
			out.println(cc.getCid()+" "+cc.getCname()+" "+cc.getCbrand());
		}
		
		Cookie[] cArr=request.getCookies();
		for(Cookie co:cArr) {
			if(co.getName().equals("cooka"))
			out.println(co.getName()+" "+co.getValue());
		}
	
		String jj=request.getQueryString();
//		out.println("<br/>"+jj);
		String[] jArr=jj.split("&");
		for(String j:jArr) {
			String[] a=j.split("=");
			if(a.length>0)
			out.println(a[1]);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
