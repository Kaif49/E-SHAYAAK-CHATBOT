package com.unisys.training;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import co.cls.mods.Cars;

/**
 * Servlet implementation class SelServe
 */
@WebServlet("/SelServe")
public class SelServe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelServe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<h1>List Of Cars In Our Garaga</h1><br/><hr/><br/>");
		//Start
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unifirst", "root", "unisys@1321");
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from cars");
			out.println("<center><table border=1><tr><td>CarID</td><td>Car Name</td><td>Car Brand</tr>");
			while(rs.next()) {
				out.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td></tr>");
			}
			out.println("</table></center>");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//End
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter out=response.getWriter();
		if(request.getParameter("cid")!=null) {
			int a=Integer.parseInt(request.getParameter("cid"));
			String b=request.getParameter("cname");
			String c=request.getParameter("cbrand");
			Cars cc=new Cars();
			cc.setCid(a);
			cc.setCname(b);
			cc.setCbrand(c);
			//Start
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unifirst", "root", "unisys@1321");
				PreparedStatement ps=conn.prepareStatement("insert into cars values("+a+",'"+b+"','"+c+"')");
				//PreparedStatement ps=conn.prepareStatement("update cars set cname='"+b+"',cbrand='"+c+"' where cid="+a);
				//ps.executeUpdate();
				ps.execute();
				out.println("Data Inserted<br/>");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//End
			
			out.print(cc.getCid()+" "+cc.getCname()+" "+cc.getCbrand());
		}
	
	
	}
	

}
