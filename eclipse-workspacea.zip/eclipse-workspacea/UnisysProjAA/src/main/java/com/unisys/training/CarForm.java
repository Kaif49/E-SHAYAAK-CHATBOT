package com.unisys.training;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.cls.mods.Cars;
import co.cls.mods.ListCars;

/**
 * Servlet implementation class CarForm
 */
@WebServlet("/CarForm")
public class CarForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		ListCars lca=new ListCars();
		List<Cars> lc=lca.retClist();
		String op="<center><form><table><tr><td>Car Id</td><td><input type=text name=cid /></td></tr>";
		op+="<tr><td>Car Name</td><td><input type=text name=cname /></td></tr>";
		op+="<tr><td>Car Brand</td><td><input type=text name=cbrand /></td></tr>";
		op+="<tr><td><input type=submit value=Send /></td><td><input type=reset value=Cancel /></td></tr></table></form></center>";
		out.println(op);
		if(request.getParameter("cname")!=null) {
			int a=Integer.parseInt(request.getParameter("cid"));
			String b=request.getParameter("cname");
			String c=request.getParameter("cbrand");
			Cars cc=new Cars();
			cc.setCid(a);
			cc.setCname(b);
			cc.setCbrand(c);
			lc.add(cc);
			out.println("<ul>");
			for(Cars ca:lc) {
				out.println("<li>"+ca.getCid()+"&nbsp;"+ca.getCname()+"&nbsp;"+ca.getCbrand()+"</li>");
			}
			out.println("</ul>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
