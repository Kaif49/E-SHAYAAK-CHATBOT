package co.cls.mods;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListCars {
	public List<Cars> retClist(){
		List<Cars> lc = new ArrayList<Cars>();
		int[] arr1= {101,201,301,401,501};
		String[] arr2= {"Octavia", "Thar", "Empala", "Camry", "EcClass"};
		String[] arr3= {"Skoda","Jeep","Ambassador","Toyota","Mercedes"};
		for (int i = 0; i< arr3.length; i++) {
			Cars c = new Cars();
			c.setCid(arr1[i]);
			c.setCname(arr2[i]);
			c.setCbrand(arr3[i]);
			lc.add(c);
		}
		
		return lc;
	}
} 
