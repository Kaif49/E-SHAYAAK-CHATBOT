package com.sata.serve;

import javax.ejb.Remote;

@Remote
public interface MYSBeanRemote {
	public String retSecLetterCaps(String a);

}
