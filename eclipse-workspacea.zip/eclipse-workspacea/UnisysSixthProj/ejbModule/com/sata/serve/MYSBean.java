package com.sata.serve;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

/**
 * Session Bean implementation class MYSBean
 */
@Stateful
@LocalBean
public class MYSBean implements MYSBeanRemote {

    /**
     * Default constructor. 
     */
    public MYSBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String retSecLetterCaps(String a) {
		// TODO Auto-generated method stub
		char[] arr=a.toCharArray();
		String u="";
		int i=1;
		for(char c:arr) {
			if(i%2==0) {
				u+=String.valueOf(c).toUpperCase();
			}else {
				u+=String.valueOf(c);
		}
			i++;
		}
		return u;
	}

}
