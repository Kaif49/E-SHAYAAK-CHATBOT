package co.sa.da.cli;

import java.util.Properties;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sat.serveb.DbBeanA;
import com.sat.serveb.DbBeanARemote;

public class MyClientCls {
	public static void main(String[] args) throws NamingException {
		DbBeanARemote dbr = EJBContext.retBean("ejb:");
		String res = dbr.retConts();
//		System.out.println(res);
		StringTokenizer str = new StringTokenizer(res, ";");
		while (str.hasMoreTokens()) {
			String u[] = str.nextToken().toString().split("-");
			for (String k : u) {
				System.out.println(k);
			}
			System.out.println("***********************");
			// System.out.println(str.nextToken().toString());
		}
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter \n1 for insert\n2 for update\n3 for delete");
		int inp = Integer.parseInt(scan.nextLine());
		switch (inp) {
		case 1:
			System.out.println("Enter the id of the person");
			int a = Integer.parseInt(scan.nextLine());
			System.out.println("Enter name of the person");
			String b = scan.nextLine();
			System.out.println("Enter dept of the person");
			String c = scan.nextLine();
			dbr.insPerson(a, b, c);
			break;
		case 2:
			System.out.println("Enter the id of the person");
			int a1 = Integer.parseInt(scan.nextLine());
			System.out.println("Enter name of the person");
			String b1 = scan.nextLine();
			System.out.println("Enter dept of the person");
			String c1 = scan.nextLine();
			dbr.upPerson(a1, b1, c1);
			break;
		case 3:
			System.out.println("Enter the id of the person");
			int a2 = Integer.parseInt(scan.nextLine());
			dbr.delPerson(a2);
			break;
		default:
			System.out.println("Unsupported operation");
			break;
		}

	}

	private static class EJBContext {
		private static DbBeanARemote retBean(String namespace) throws NamingException {
			return retLookUp(namespace);
		}

		private static DbBeanARemote retLookUp(String namespace) throws NamingException {
			Context ctx = creaInitContext();
			String appName = "";
			String moduleName = "UnisysEighthProj";
			String distinctName = "";
			String beanName = DbBeanA.class.getSimpleName();
			String viewClassName = DbBeanARemote.class.getName();
			return (DbBeanARemote) ctx.lookup(namespace + appName + "/" + moduleName + "/" + distinctName + "/"
					+ beanName + "!" + viewClassName + "?stateful");
		}

		private static Context creaInitContext() throws NamingException {
			Properties props = new Properties();
			props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
			props.put("jboss.naming.client.ejb.context", true);
			return new InitialContext(props);
		}
	}

}