package co.sa.cl;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class ABean
 */
@Stateless
@LocalBean
public class ABean implements ABeanRemote {

    /**
     * Default constructor. 
     */
    public ABean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String tester() {
		return "Tester String";
	}

}
