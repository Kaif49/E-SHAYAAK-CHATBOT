package co.sa.cl;

import javax.ejb.Remote;

@Remote
public interface ABeanRemote {
	public String tester();
}
