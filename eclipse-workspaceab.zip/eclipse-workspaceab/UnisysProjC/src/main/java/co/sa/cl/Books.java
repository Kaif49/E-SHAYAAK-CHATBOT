package co.sa.cl;

public class Books {
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBanme() {
		return banme;
	}
	public void setBanme(String banme) {
		this.banme = banme;
	}
	public String getBauth() {
		return bauth;
	}
	public void setBauth(String bauth) {
		this.bauth = bauth;
	}
	private int bid;
	private String banme;
	private String bauth;

}
