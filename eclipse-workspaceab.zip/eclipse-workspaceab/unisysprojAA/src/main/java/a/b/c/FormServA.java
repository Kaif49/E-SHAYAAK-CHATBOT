package a.b.c;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import cars.a.c.Cars;
import cars.a.c.ListCars;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormServA
 */
@WebServlet("/FormServA")
public class FormServA extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormServA() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		if(request.getParameter("cid")!=null) {
			int a=Integer.parseInt(request.getParameter("cid"));
			String b=request.getParameter("cname");
			String c=request.getParameter("cbrand");
			Cars cc=new Cars();
			cc.setCid(a);
			cc.setCname(b);
			cc.setCbrand(c);
			
			
			out.print(cc.getCid()+" "+cc.getCname()+" "+cc.getCbrand());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter out=response.getWriter();
		if(request.getParameter("cid")!=null) {
			int a=Integer.parseInt(request.getParameter("cid"));
			String b=request.getParameter("cname");
			String c=request.getParameter("cbrand");
			Cars cc=new Cars();
			cc.setCid(a);
			cc.setCname(b);
			cc.setCbrand(c);
			
			//Start
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unifirst", "root", "unisys@1321");
				PreparedStatement ps=conn.prepareStatement("insert into cars values("+a+",'"+b+"','"+c+"')");
				ps.execute();
//				out.println("Data Inserted<br/>");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			//End
			
//			out.print(cc.getCid()+" "+cc.getCname()+" "+cc.getCbrand());
			response.sendRedirect("./FormA.html");
		}
	
	
	}
	

}
