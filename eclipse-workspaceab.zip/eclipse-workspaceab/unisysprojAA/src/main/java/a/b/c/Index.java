package a.b.c;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.function.Consumer;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cars.a.c.Cars;
import cars.a.c.ListCars;
/**
 * Servlet implementation class Index
 */
@WebServlet("/Index")
public class Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Index() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		List<Cars> lc=null;
		ListCars lcObj=new ListCars();
		lc=lcObj.retCList();
		String disp="<center><table border=1 style=\"background-color:black;color:yellow;\"><thead><tr><th>Car ID</th><th>Car Name</th><th>Car Brand</th></tr></thead><tbody>";
		for(Cars c:lc) {
			disp+="<tr><td>"+c.getCid()+"</td><td>"+c.getCname()+"</td><td>"+c.getCbrand()+"</td></tr>";
		}
		disp+="</tbody></table><center>";
		out.println("<center><h1>Welcome to car show room we have following cars for display</h1></center><br/><hr/><br/>");
		out.println(disp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
