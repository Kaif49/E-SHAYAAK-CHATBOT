package a.b.c;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cars.a.c.Cars;
import cars.a.c.ListCars;

/**
 * Servlet implementation class DetServe
 */
@WebServlet("/DetServe")
public class DetServe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DetServe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		out.println("Welcome to selection");
		List<Cars> lc=null;
		ListCars lcObj=new ListCars();
		lc=lcObj.retCList();
		String op="<form><select name=sel>";
		for(Cars c:lc) {
			op+="<option value="+c.getCid()+">"+c.getCid()+"</option>";
		}
		op+="</select><input type=submit value=Get /></form>";
		out.println(op);
		if(request.getParameter("sel")!=null) {
//			out.println("<br/>Selected Car Id is "+request.getParameter("sel"));
			String cont="<br/><span>Details of the car selected</span><br/><h2>";
			for(Cars c:lc) {
				if(c.getCid()==Integer.parseInt(request.getParameter("sel")))
				cont+="Name:"+c.getCname()+"<br/>Brand:"+c.getCbrand();
			}
			cont+="</h2>";
			out.println(cont);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
