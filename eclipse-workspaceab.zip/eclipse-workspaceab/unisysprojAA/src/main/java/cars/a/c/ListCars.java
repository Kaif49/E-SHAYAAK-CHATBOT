package cars.a.c;
import java.util.ArrayList;
import java.util.List;
public class ListCars {
	public List<Cars> retCList(){
		List<Cars> lc=new ArrayList<Cars>();
		int[] arr1= {101,201,301,401,501};
		String[] arr2= {"Octavio","Thar","Empala","Camry","ECclass"};
		String[] arr3= {"Skoda","Jeep","Ambassador","Toyota","Mercedes"};
		for (int i = 0; i < arr3.length; i++) {
			Cars c=new Cars();
			c.setCid(arr1[i]);
			c.setCname(arr2[i]);
			c.setCbrand(arr3[i]);
			lc.add(c);
		}
		return lc;
	}
}
