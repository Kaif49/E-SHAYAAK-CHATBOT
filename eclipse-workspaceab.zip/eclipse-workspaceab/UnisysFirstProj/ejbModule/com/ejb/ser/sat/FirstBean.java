package com.ejb.ser.sat;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class FirstBean
 */
@Stateless
public class FirstBean implements FirstBeanRemote {

    /**
     * Default constructor. 
     */
    public FirstBean() {
        // TODO Auto-generated constructor stub
    }
    public String myMetha() {
    	return "welcome to EJB";
    }

}
