package com.ejb.ser.sat;

import javax.ejb.Remote;

@Remote
public interface FirstBeanRemote {
	public String myMetha();
 

}
